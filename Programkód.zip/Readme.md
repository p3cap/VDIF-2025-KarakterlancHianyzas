# VDIF KarakterlancHiányzás
Vadász Dénes Informatika Verseny
 
*csapatnév*: <karakterlánc hiányzás> csapat

*iskola:* BMSZC Puskás Tivadar Távközlési és Informatikai Technikum

*Csapat tagjai:* Dobosi Péter, Kovács Dávid, Vaszkó Örs

*Felkészítő tanár és elérhetősége:* Zámbó Dominik, zambo.dominik@puskas.hu

*Fejlesztői környezet:* Python 3

*feladat rövid leírása:* város építő szimuláció program és adatkimutatások

### *Használat:*
- _**main.py**_ elindításával a program már fut is!
- a szimuláció elkezdéséhez
- mentett szimuációs adatok mappájának neve: *saves*
